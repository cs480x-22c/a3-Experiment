// https://github.com/levinunnink/html-form-to-google-sheet
const scriptURL = 'https://script.google.com/macros/s/AKfycbxESvoK6oBvY0xef9CPhUIzoNcd8-8oNzglySb0iOI0DE1pOhbx9uuY1-0YKYFdSgBVEw/exec'
const input = document.forms['input']
const output = document.forms['output']

//https://linuxhint.com/set-check-read-cookie-javascript/
function setCookie(key, value) {
  document.cookie = key + "=" + value + ";" + "expires=Tue, 19 Jan 2038 04:14:07 GMT";
}

function getCookie(key) {
  let name = key + "=";
  let spli = document.cookie.split(';');
  for(var j = 0; j < spli.length; j++) {
    let char = spli[j];
    while (char.charAt(0) == ' ') {
      char = char.substring(1);
    }
    if (char.indexOf(name) == 0) {
      return char.substring(name.length, char.length);
    }
  }
  return "";
}

function checkCookie(key) {
  var val = getCookie(key);
  // checking whether cookie is null or not
  if (val == "") {
    //take input from user
	user = prompt("Please enter a username. It will be stored as a cookie.", "");
	while(user == "" | user == null) {
		user = prompt("Please enter a username. It will be stored as a cookie.", "");
	}
    //set cookie
    if (user != "" && user != null) {
	  setCookie("username", user);
	  setCookie("id", crypto.randomUUID())
    }
  }
  d3.select("#id").attr("value", getCookie("id"))
  d3.select("#username").attr("value", getCookie("username"))
  d3.select("#welcome").text(`Welcome ${getCookie("username")}!`)
}

function resetPage(){
	d3.select("#chart").remove()
	d3.selectAll(".guess").attr("type", "hidden")
	d3.select("#instructions").text("")
}

function shuffle(array){
  let currentIndex = array.length,  randomIndex;

  // While there remain elements to shuffle...
  while (currentIndex != 0) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    // And swap it with the current element.
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }

  return array;
}
 
input.addEventListener('submit', e => {
	e.preventDefault();
	switch(charts[times]){
		case "bar":
			d3.select("#barError").attr("value", document.input.barGuess.value - real)
			break;
		case "circle":
			d3.select("#circleError").attr("value", document.input.circleGuess.value - real)
			break;
		case "pie":
			d3.select("#pieError").attr("value", document.input.pieGuess.value - real)
			break;
	}
	times++
	if (times < 3){
		resetPage()
		generate_chart(5, 100, "#vis", charts[times])
	}
	else{
		resetPage()
		d3.select("#instructions").text("Thank you for answering! You are encouraged to reload the page and participate again.")
		d3.selectAll(".end").attr("hidden", "hidden")
		fetch(scriptURL, { method: 'POST', body: new FormData(output)})
			.then(response => console.log('Success!', response))
			.catch(error => console.error('Error!', error.message))
		document.getElementById('output').reset();
	}
  })

//Generate Data
function generate_data(num, max){
	var dict = []
	for(i = 0; i< num; i++){
		var x = String.fromCharCode(i + 65)
		var y = Math.floor(Math.random() * (max - 1)) +1;
		dict.push({
			key:   x,
			value: y
			})
	}
	return dict
}

//Function for generating which two bars should be compared (first index vs last, 2nd vs 4th, ect)
function generateIndexes(num) {
    var compareIndexA = Math.floor(Math.random() * num);
    var compareIndexB = compareIndexA;
    //make sure compared bars are not the same or next to each other
    while(compareIndexA === compareIndexB | Math.abs(compareIndexA - compareIndexB) === 1){
      compareIndexB = Math.floor(Math.random() * num);
    }
    return [compareIndexA, compareIndexB];
}

function generate_chart(num, max, elm, type){
	var data = generate_data(num, max)
	var svg = d3.select(elm).append("svg");
	var g = svg.append("g")
	var compareIndexes = this.generateIndexes(num);
    var compareIndexA = compareIndexes[0];
    var compareIndexB = compareIndexes[1];
	var compareLetterA = String.fromCharCode(compareIndexes[0] + 65)
	var compareLetterB = String.fromCharCode(compareIndexes[1] + 65)
	real =  100 * (data[compareIndexA].value / data[compareIndexB].value);
	
	console.log(type)
	console.log(compareIndexA)
	console.log(data[compareIndexA])
	console.log(compareIndexB)
	console.log(data[compareIndexB])
	console.log(real)
	
	d3.select("#instructions").text(`${compareLetterA} is what percentage of ${compareLetterB}? Answer in the box below.`)
	svg.attr("id", "chart")
	switch (type){
		case "bar":
			d3.select("#barGuess").attr("type", "number")
			
			var margin = {top: 10, right: 30, bottom: 30, left: 100};
			let w = 300;
			let h = 200; 

			svg.attr('height', h + margin.top + margin.bottom)
				.attr("viewBox", '0 0 100 110')

			svg.selectAll('rect')
				.data(data)
				.enter().append('rect')
				.attr('x', function(d, i){return (i*8)+50})
				.attr('y', function(d){return 100 - d.value})
				.attr('width', '5%')
				.attr('height', function(d){return d.value})
				.attr('stroke', 'black')
				.attr('stroke-width', 0.5)
				.attr('fill', 'white');
			
			svg.selectAll("text")
				.data(data)
				.enter().append("text")
				.attr('y', '106')
				.attr('x', function(d, i){return (i*8)+50})
				.style("font-size", "6px")
				.text(function(d, i){
					return d.key; 
				});
			break;
		case "circle":
			d3.select("#circleGuess").attr("type", "number")
			var circles = svg.selectAll('circle')
				.data(data)
				.enter().append('circle')
				.attr('cx', function(d, i){return (i*110)+100})
				.attr('cy', 50)
				.attr('r', function(d){return d.value/2})
				.attr('height', function(d){return d.value})
				.attr('stroke', 'black')
				.attr('stroke-width', 0.5)
				.attr('fill', 'white');

			svg.selectAll("text")
				.data(data)
				.enter().append("text")
				.attr('y', '150')
				.attr('x', function(d, i){return (i*110)+100})
				.style("font-size", "12px")
				.text(function(d, i){
					return String.fromCharCode(i + 65); 
				});
			break;
		case "pie":
			d3.select("#pieGuess").attr("type", "number")
			// https://www.geeksforgeeks.org/d3-js-pie-function/
			g.attr("transform", "translate(150,120)");
          
			// Creating Pie generator
			var pie = d3.pie()
				.value(function(d) {return d.value; })
			var data_ready = pie(data.values)
  
			// Creating arc
			var arc = d3.arc()
                .innerRadius(0)
                .outerRadius(100);
  
			// Grouping different arcs
			var arcs = g.selectAll("arc")
                .data(pie(data))
                .enter()
                .append("g");
  
			// Appending path 
			arcs.append("path")
				.attr("fill", "white")
				.attr("stroke", "black")
				.attr("d", arc);
			
			//Append Text
			arcs.append("text")
				.attr("transform",(d)=>{ 
                    var _d = arc.centroid(d);
					_d[0] *= 2.3;	//multiply by a constant factor
					_d[1] *= 2.3;	//multiply by a constant factor
					return "translate(" + _d + ")"; 
				})
				.text(function(d){
					return d.data.key; 
				});
			break;
		default:
			console.log(`${type} not a valid chart type.`);
	}
}
var barError = 0
var circleError = 0
var pieError = 0
var times = 0
var real = 0
var charts = shuffle(["bar", "circle", "pie"])

checkCookie("username")
generate_chart(5, 100, "#vis", charts[times])